import './style.css'

window.DB = {
  meta: {
    name: "sistema-transporte-ruta99",
    version: "1.0.0",
    description: "Proyecto final Ruta99: venta de camionetas, precios, chofer asignado, mapa con API gratuita, denuncias de placas y datos de conductor.",
    main: "index.html",
    scripts: {
      start: "echo \"Este proyecto es solo HTML, CSS y JS. Abre index.html.\""
    },
    keywords: ["transporte","rutas","mapas","choferes","camionetas","denuncias"],
    author: "Angel Alexander Arias Gutierrez",
    license: "MIT"
  },
  rutas: [
    {
      id: "R99",
      nombre: "Ruta 99",
      base: "Base Central Sur",
      color: "#ff9900",
      paradas: [
        "Base Central Sur",
        "Av. Universidad",
        "Mercado Central",
        "Plaza Reforma",
        "Terminal Norte"
      ]
    },
    {
      id: "R52",
      nombre: "Ruta 52",
      base: "Terminal Oriente",
      color: "#0099ff",
      paradas: [
        "Terminal Oriente",
        "Hospital General",
        "Centro Histórico",
        "Parque Industrial"
      ]
    },
    {
      id: "R14",
      nombre: "Ruta 14",
      base: "Base Poniente",
      color: "#44aa44",
      paradas: [
        "Base Poniente",
        "Unidad Deportiva",
        "Escuela Técnica 43",
        "Colonia Jardines"
      ]
    }
  ],
  unidades: [
    {
      placas: "R99-324",
      modelo: "Nissan Urvan",
      anio: 2019,
      estado: "Activa",
      ruta: "R99",
      chofer: "Juan Perez"
    },
    {
      placas: "R99-151",
      modelo: "Toyota Hiace",
      anio: 2020,
      estado: "En mantenimiento",
      ruta: "R99",
      chofer: "Miguel Torres"
    },
    {
      placas: "R52-778",
      modelo: "Nissan NV350",
      anio: 2018,
      estado: "Activa",
      ruta: "R52",
      chofer: "Eduardo Ríos"
    },
    {
      placas: "R14-229",
      modelo: "Toyota Hiace",
      anio: 2021,
      estado: "Activa",
      ruta: "R14",
      chofer: "Luis Hernández"
    }
  ],
  choferes: [
    {
      nombre: "Juan Perez",
      edad: 37,
      telefono: "555-123-456",
      licencia: "B-12345",
      unidad: "R99-324",
      ruta: "R99",
      turno: "Matutino"
    },
    {
      nombre: "Miguel Torres",
      edad: 42,
      telefono: "555-789-321",
      licencia: "B-54321",
      unidad: "R99-151",
      ruta: "R99",
      turno: "Vespertino"
    },
    {
      nombre: "Eduardo Ríos",
      edad: 30,
      telefono: "555-678-900",
      licencia: "B-98765",
      unidad: "R52-778",
      ruta: "R52",
      turno: "Completo"
    },
    {
      nombre: "Luis Hernández",
      edad: 35,
      telefono: "555-443-210",
      licencia: "B-19283",
      unidad: "R14-229",
      ruta: "R14",
      turno: "Matutino"
    }
  ]
};